<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <title><?php bloginfo('name'); ?></title>
    <meta name="description" content="<?php bloginfo('description'); ?>" />
    <meta name="author" content="<?php bloginfo('name'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/style.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/animation.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/fontello.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/fontello-codes.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/fontello-embedded.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/fontello-ie7.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/fontello-ie7-codes.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/src/css/fa.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Exo+2' rel='stylesheet' type='text/css'>
    <link rel="shortcut icon" href="<?php $favicon = ayar("opt-favicon"); echo $favicon["url"]; ?>" type="image/x-icon" />
    <?php 
      $getMyStyles = ayar("opt-css");
      $cleanMyStyles = CleanCode("style", $getMyStyles);
      if($cleanMyStyles) echo '<style type="text/css">'.$cleanMyStyles.'</style>';
    ?>
    <?php wp_head(); ?>

</head>
<body>

  <div class="container-fluid ust-alan" style="padding: 0px; position: relative;">
      <div class="container">
        <div class="col-md-4 sosyaller visible-lg" style="position: absolute; right:10%; top:10px; z-index: 10000;">
            <a href="<?php echo ayar("text-facebook"); ?>" title="Facebook"><i class="icon-facebook"></i></a>
            <a href="<?php echo ayar("text-twitter"); ?>" title="Twitter"><i class="icon-twitter-3"></i></a>
            <a href="<?php echo ayar("text-google"); ?>" title="Google+"><i class="icon-gplus"></i></a>
            <a href="<?php echo ayar("text-android"); ?>" title="Android"><i class="icon-android"></i></a>
            <span style="color: #b8b8b8; font-size: 16px; padding: 10px; vertical-align: text-bottom; margin-top: -5px;">kısa yollar</span>
            <?php 
              if(is_user_logged_in()) {
                echo uye_profil();
              } else {
                echo uye_login();
              } 
            ?>
        </div>
        <div class="clearfix"></div>
      </div>


    <nav class="navbar navbar-default navbar-static-top" style="margin-bottom: 0px;">
      <div class="navbar-header" style="border: none;">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" style="background: #f05252; border-color: #f05252; padding: 8px; border-radius:0px; font-weight: 600;">
          <span class="sr-only">AspavA</span>
          <span style="color: #FFF; font-weight: 600;">Menü</span>
        </button>
          <a class="navbar-brand hidden-sm hidden-md hidden-lg" href="#">
          <?php 
            $logo = ayar("opt-logo-mobil");
            echo '<img src="'.$logo["url"].'" width="'.ifReplace($logo["width"], "").'" height="'.ifReplace($logo["height"], "").'" alt="'.get_bloginfo('name').'" class="mlogo">';
          ?>
          </a>
      </div>



      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <div class="col-md-5 col-sm-12 sol-taraf" style="padding: 0px;">
            <ul class="nav navbar-nav sol-menu">
                <li><a href="<?php echo home_url( '/' ); ?>"><i class="icon-home"></i> Ana Sayfa</a></li>
                <li><a href="<?php echo home_url( '/blog/' ); ?>"><i class="icon-pencil"></i> Blog</a></li>
                <li><a href="<?php echo get_post_type_archive_link( 'hikayeler' ); ?>"><i class="icon-coffee"></i> Hikayeler</a></li>
                <?php 
                  echo strip_tags(wp_nav_menu(array( 'theme_location' => 'left-menu', 'echo' => false)), '<li><a><i>'); 
                ?>
            </ul>
          </div>

          <div class="col-md-2 hidden-sm" style="padding: 0px;"> 
            <a href="<?php echo home_url( '/' ); ?>" title="<?php get_bloginfo('name'); ?>">
              <?php 
                $logo = ayar("opt-logo");
                echo '<img src="'.$logo["url"].'" width="'.ifReplace($logo["width"], "").'" height="'.ifReplace($logo["height"], "").'" alt="'.get_bloginfo('name').'" class="logo">';
              ?>
            </a>
          </div>

          <div class="col-md-5 col-sm-12 sag-taraf" style="padding: 0px;">
            <ul class="nav navbar-nav navbar-right sag-menu">
                <li><a href="#" class="menu2">Sohbete Bağlan <p style="margin-left: 50px; margin-top: 0px; padding: 0px;" ><i class="glyphicon glyphicon-triangle-bottom" style="color: #00213f; font-size: 40px; z-index: 10001; padding: 0px;"></i></p></a></li>

                <?php 
                  echo strip_tags(wp_nav_menu(array( 'theme_location' => 'right-menu', 'echo' => false)), '<li><a><i>'); 
                ?>
            </ul>
          </div>
      </div><!-- /.navbar-collapse -->
    </nav>

    <div class="container" style="padding: 0px;">
      <div class="col-md-12 detay-sohbet-alani">
        <div class="col-md-10" style="padding: 0px;">
          <form class="form-inline" action="<?php $mirc = ayar("opt-mirc"); echo get_page_link($mirc); ?>">
            <div class="input-group col-md-4 detay-asp2" style="margin-top:5px;">
              <span class="input-group-addon danger" style="background: #fff !important; border: none;"><img src="<?php echo get_template_directory_uri(); ?>/src/images/kadico.png" alt="icon" width="57" height="28" /></span>
              <input type="text" name="isim" class="form-control" placeholder="Kullanıcı adınız">
              </div>
            <div class="input-group col-md-4 detay-asp2" style="margin-top:5px;">
              <span class="input-group-addon danger" style="background: #fff !important; border: none;"><img src="<?php echo get_template_directory_uri(); ?>/src/images/sifreico.png" alt="icon" width="57" height="28" /></span>
              <input type="text" name="isim" class="form-control" placeholder="şifreniz (varsa giriniz)">
            </div>
            <button type="submit" name="gonder" style="margin-top:5px;"  class="btn btn-detay-asp btn-sm"><img src="<?php echo get_template_directory_uri(); ?>/src/images/baglanico.png" alt="icon" width="54" height="41" />sohbete bağlan</button>
          </form>
        </div>
        <div class="col-md-2 hidden-xs" style="margin-top: 8px;">
          <a href="<?php $mirc = ayar("opt-radyo"); echo get_page_link($radyo); ?>" title="titlesi" class="detay-radyo"><i class="icon-play" style=" vertical-align: text-top;"></i></a>
          <a href="#" title="titlesi" class="detay-kayit"><img src="<?php echo get_template_directory_uri(); ?>/src/images/kayitico.png" alt="icon" width="30" height="32" style="margin-right: 5px;" /></a>
        </div>
      </div>
    </div>