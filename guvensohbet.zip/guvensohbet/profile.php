<?php get_header(); ?>

<?php 
	$uid = get_query_var('user_id');
	$userData = get_userdata($uid);
	$userMeta = get_user_meta($uid);
	$getUsers = get_users( array("number" => 16 ) );
?>

<div class="clearfix"></div>

<div class="container detay-genel" style="padding: 0px 10px; margin-top: 8px;">
	<div class="col-md-12 detay-baslik" style="padding: 0px; margin-top: 20px;">
		<span style="color: #515151"><a href="<?php echo home_url( '/' ); ?>" title="titlesi">Ana sayfa |</a></span>
		<a href="#" title="titlesi"><?php echo ($userData) ? $userData->user_login . ' adlı kullanıcının profili' : 'Bilinmeyen Kullanıcı'; ?></a>
	</div>
	<div class="col-md-12" style="padding: 0px;margin-top: 5px;">
		
		<?php if($userData): ?>
	        <div class="media">
	          <div class="media-left">
	            <?php echo userAvatar($uid, "media-object", 220); ?>
	          </div>
	          <div class="media-body">
	            <h4 class="media-heading" style="font-size: 18px;color: #7b7b7b;font-weight: 600;margin-bottom: 10px;border-bottom: 1px dashed;padding-bottom: 10px;"><span class="c1"><?php echo $userData->user_login; ?></span> Nick'li Kullanıcının Profili</h4>
	            <ul class="tam-profil">
	              <li>Nick:  <span class="c1"><?php echo $userData->display_name; ?></span></li>
	              <li>Adı:  <span class="c1"><?php echo ifReplace($userData->user_firstname); ?></span></li>
	              <li>Soyadı:  <span class="c1"><?php echo ifReplace($userData->user_lastname); ?></span></li>
	              <li>Cinsiyet:  <span class="c1"><?php echo ifReplace($userMeta['gender'][0]); ?></span></li>
	              <li>Yaşadığı Şehir:  <span class="c1"><?php echo ifReplace($userMeta['city'][0]); ?></span></li>
								<li>Doğum Tarihi:  <span class="c1"><?php echo ifReplace($userMeta['birthday'][0]); ?></span></li>
	              <li>Üyelik Tarihi:  <span class="c1"><?php echo $userData->user_registered; ?></span></li>
	            </ul>
	          </div>
	        </div>

	      <h4 style="font-size: 16px;color: #7b7b7b;margin: 30px 0 20px;font-weight: 700;">Biyografi</h4>

        <div class="panel panel-default" style="min-height: 150px;">
          <div class="panel-body">
          <?php echo ifReplace($userMeta['description'][0], 'Henüz bir hayat hikaye\'si oluşturulmamış.'); ?>
          </div>
        </div>
		<?php else: ?>
			<div class="alert alert-danger" role="alert">
			  <strong>Maalesef!</strong> böyle bir kullanıcı kaydı bulunamadı!
			</div>
		<?php endif; ?>


		<?php if(ayar("reklam-on") == 1): ?>
		<div class="col-md-10 detay-reklam-alani col-md-offset-2">
			<?php echo ayar("opt-reklam"); ?>
		</div>
		<?php endif; ?>
	</div>
</div>

</div>

<div class="clearfix"></div>

<?php get_footer(); ?>