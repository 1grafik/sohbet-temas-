<?php 
/*
Theme Name: GuvenSohbet Teması
Author: 1Grafik.
Author URI:  https://www.1grafik.com
Version: 1.0.0
*/


///////////////// INCLUDES /////////////////////
// PLUGIN.PHP
include_once ABSPATH . 'wp-admin/includes/plugin.php';
// TEMA PANEL
if(!class_exists("ReduxFrameworkPlugin")){
    require_once(get_template_directory()."/options/redux-framework.php");
    require_once(get_template_directory()."/options/custom/config.php");
}
/////////////// INCLUDES BİTTİ ////////////////


// MENÜ OLUŞTUR
function menu_create(){
	register_nav_menus( 
		array(
			'left-menu' => __( 'Üst Sol Menu' ),
			'right-menu' => __( 'Üst Sağ Menü' ),
			'footer-menu-1' => __( 'Footer 1. Menü' ),
			'footer-menu-2' => __( 'Footer 2. Menü' ),
			'footer-menu-3' => __( 'Footer 3. Menü' ),
		)
	);
}

add_action( 'init', 'menu_create' );

// Ön Görsel Desteği
add_theme_support( 'post-thumbnails' );


// İF EMPTY REPLACE
function ifReplace($val, $replace = '-') {
	$val = trim($val);
	return (isset($val) && !empty($val)) ? $val : $replace;
}

// TEMA AYAR ÇEK
$ReduxOptions = get_option( 'redux_opt' );
function ayar($text=false){
	global $ReduxOptions;
	$a = "";
	$new_text = @preg_replace('/\s+/', '', $text);
	if(!empty($new_text) && is_array($ReduxOptions)){
		$arr = @explode(',', $new_text);
		switch(count($arr)){
			case 1:
			$a = $ReduxOptions[$arr[0]];
			break;
			case 2;
			$a = $ReduxOptions[$arr[0]][$arr[1]];
			break;
			case 3;
			$a = $ReduxOptions[$arr[0]][$arr[1]][$arr[2]];
			break;
			default:
			$a = $ReduxOptions[$arr[0]];
		}
	}
	return $a;
}


///////// KULLANICI KAYDI ///////////
function register_a_user() {
	$errors = array();

	if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['password_confirm'])) {
		$errors[] = 'Kullanıcı adı, email ve şifre alanlarını doldurunuz.';
	}

	if ($_POST['password'] != $_POST['password_confirm']) {
		$errors[] = 'Şifreler birbiriyle uyuşmuyor.';
	}

	$username = esc_attr( $_POST['username'] );
	$user_email = esc_attr( $_POST['email'] );
	$user_pass = esc_attr( $_POST['password'] );
	$gender = esc_attr( $_POST['gender'] );
	$city = esc_attr( $_POST['city'] );
	$birthday = esc_attr( $_POST['birthday'] );
	require_once( ABSPATH . WPINC . '/registration.php' );
	$sanitized_user_login = sanitize_user( $username );
	$user_email = apply_filters( 'user_registration_email', $user_email );

	if (!is_email( $user_email )) {
		$errors[] = 'Geçersiz e-posta adresi';
	}
	else {
		if (email_exists( $user_email )) {
			$errors[] = 'Bu e-posta zaten kayıtlı.';
		}
	}

	if (( empty( $sanitized_user_login ) || !validate_username( $username ) )) {
		$errors[] = 'Geçersiz kullanıcı adı';
	}
	else {
		if (username_exists( $sanitized_user_login )) {
			$errors[] = 'Kullanıcı adı zaten kayıtlı';
		}
	}
	if (empty( $errors )) {
		$user_id = wp_create_user( $sanitized_user_login, $user_pass, $user_email );

		if (!$user_id) {
			$errors[] = 'Kayıt başarısız...';
		}
		else {
			update_user_option( $user_id, 'default_password_nag', true, true );
			wp_new_user_notification( $user_id, $user_pass );
			add_user_meta( $user_id, 'gender', $gender, true );
			add_user_meta( $user_id, 'city', $city, true );
			add_user_meta( $user_id, 'birthday', $birthday, true );
			add_user_meta( $user_id, 'uAvatar', '', true );
		}
	}
	if (!empty( $errors )) {
		define( 'REGISTRATION_ERROR', serialize( $errors ) );
		return null;
	}

	define( 'REGISTERED_A_USER', $username);
	define( 'REGISTERED_A_USER_EMAIL', $user_email);
	define( 'REGISTERED_A_USER_PASS', $user_pass);
}

if(isset($_POST['userRegisterForm'])){
	register_a_user();
}


///////// KULLANICI GÜNCELLEME ///////////
function update_a_user() {
	$errors = $updates = array();
	$updateItems = array('display_name' => 'nickadi', 'user_email' => 'eposta', 'user_pass' => 'parola', 'first_name' => 'adi', 'last_name' => 'soyadi', 'description' => 'biyografi');
	$current_user = wp_get_current_user();

	if (isset($_POST['user_email']) && !empty($_POST['user_email'])) {
		$user_email = apply_filters( 'user_registration_email', $user_email );

		if (!is_email( $user_email )) {
			$errors[] = 'Geçersiz e-posta adresi';
		}
		else {
			if ($current_user->user_email != $user_email && email_exists( $user_email )) {
				$errors[] = 'Bu e-posta zaten kayıtlı.';
			}
		}
	}

	foreach ($updateItems as $key => $value) {
		if(isset($_POST[$value]) && !empty($_POST[$value])) { 
			$updates[$key] = esc_attr( $_POST[$value] ); 
		}
	}

	if (empty( $errors )) {
		$updates['ID'] = $current_user->ID;
		$user_id = wp_update_user( $updates );

		if (is_wp_error( $user_id )) {
			$errors[] = 'Bir sorun oluştu.';
		}
		else {
			if(isset($_POST['gender']) && !empty($_POST['gender'])) { update_user_meta( $current_user->ID, 'gender', $_POST['gender']); }
			if(isset($_POST['city']) && !empty($_POST['city'])) { update_user_meta( $current_user->ID, 'city', $_POST['city']); }
			if(isset($_POST['birthday']) && !empty($_POST['birthday'])) { update_user_meta( $current_user->ID, 'birthday', $_POST['birthday']); }
			if(isset($_POST['uAvatar']) && !empty($_POST['uAvatar'])) { update_user_meta( $current_user->ID, 'uAvatar', $_POST['uAvatar']); }
		}
	}
	if (!empty( $errors )) {
		define( 'UPDATED_ERROR', serialize( $errors ) );
		return null;
	}
	define( 'UPDATED_A_USER', true);
}

if(isset($_POST['userUpdateForm'])){
	update_a_user();
}

// ÜYE PROFİL
function uye_profil() {
	$current_user = wp_get_current_user();
	$url = get_bloginfo('url');
	$yazdir .= '
	<div class="dropdown" id="login_in_nav">
		<button id="dLabel" class="btn" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<span class="icon-user"></span> '.$current_user->user_login.' <span class="caret"></span>
		</button>
		<ul class="dropdown-menu" aria-labelledby="dLabel">
			<li><a href="'.$url.'/profile/'.$current_user->ID.'/"><span class="icon-eye"></span> Profili Görüntüle</a></li>
			<li><a href="'.$url.'/profile/"><span class="icon-cog"></span> Profili Düzenle</a></li>
			<li role="separator" class="divider"></li>
			<li><a href="'.wp_logout_url( $url ).'"><span class="icon-logout"></span> Çıkış</a></li> 
		</ul>
	</div>';
	return $yazdir;
}

// ÜYE GİRİŞ
function uye_login() {
	$yazdir .= '
	<a href="#" data-toggle="modal" data-target="#loginModal" id="loginBtn" class="btn"><span class="icon-login"></span> Giriş</a>

	<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="loginModalLabel">Giriş Yap</h4>
	      </div>
	      <form method="post" action="'.wp_login_url( home_url() ).'">
		      <div class="modal-body">
				<input type="text" name="log" id="user_login" placeholder="Kullanıcı Adı">
				<input type="password" name="pwd" id="user_pass" placeholder="Şifreniz">
				<input name="login" type="hidden" id="login" value="submit">
				<label><input name="rememberme" type="checkbox" id="rememberme" value="forever"> Beni Hatırla</label>
		      </div>
		      <div class="modal-footer">
		        <a class="btn btn-default" href="'.wp_lostpassword_url().'">Şifremi Unuttum</a>
		        <button type="submit" class="btn">Giriş Yap</button>
		      </div>
	     </form>
	      </div>
	    </div>
	  </div>';
	return $yazdir;
}

// User Avatar
function userAvatar($id, $class = false, $size = 120) {
	$uAvatar = get_user_meta($id, 'uAvatar', true);
	$uAvatar = ifReplace($uAvatar, "");
	if(!empty($uAvatar)) {
		return '<img'.((isset($class) && !empty($class)) ? ' class="'.$class.'"' : null).' src="'.$uAvatar.'" width="'.$size.'" alt="avatar" />';
	} else {
		$class = (isset($class) && !empty($class)) ? @explode(' ', $class) : array();
		return get_avatar( $id, $size, "", false, array('class' => $class));
	}
}

// YENİ ÜYELER
function yeniUyeler() {
	$i = $k = 0;
	$array = array();
	$getUsers = get_users( array( "role" => "subscriber", "number" => 16 ) );
	foreach ($getUsers as $user) {
		$array[$k][] = '
		<div class="col-sm-3 col-xs-6 col-md-2" style="margin-bottom: 5px;">
			<a href="'.get_bloginfo('url').'/profile/'.$user->ID.'/" class="profiller" title="titlesi" style="text-decoration: none;" >
				<div class="uyeleri-diz">
					'.userAvatar($user->ID, "img-responsive uyeleri-diz-imgler", 100).'
					<div class="caption" style="margin-top: 0px;">
						<p style="padding: 0px 0px;">'.$user->display_name.'</p>
					</div>
				</div>
			</a>
		</div>';
		$i++;
		if($i%6 == 0) { $k++; }
	}
	return $array;
}

// GÖRSEL ÇAĞIRMA
function GetThumb($thumb,$class=false){
	global $post;
	$yazdir = '';
	$class = ( isset($class) && !empty($class) ) ? $class : "";
	if( function_exists("has_post_thumbnail") && has_post_thumbnail() ){ 
		$yazdir .= get_the_post_thumbnail($post->ID, $thumb, array('class' => $class, 'alt' => get_the_title(), 'title' => get_the_title()));
	} else {
		$yazdir = '<img src="'.get_template_directory_uri().'/src/images/noimg.png" alt="'.get_the_title().'"'.(($class != "") ? ' class="'.$class.'"' : null).' width="500" height="270" />';
	}
	return $yazdir;
}

// MENU İSİM GETİR
function getMenuTitle() {
	$menu_locations = (array) get_nav_menu_locations();
	$menu = array();
	if(!empty($menu_locations)) {
		foreach ($menu_locations as $key => $value) {
			$getTerm = get_term_by( 'id', (int) $menu_locations[ $key ], 'nav_menu', ARRAY_A );
			$menu[$key] = $getTerm['name'];
		}
	}
	return $menu;
}

// SAYFALAMA
function sayfalama($pages = 1, $paged, $range = 3) {
	$showitems = ($range * 2)+1;
	if(empty($paged)) $paged = 1;
	if($pages == '') {
	$pages = 1;
	}
	echo '<nav aria-label="Page navigation"><ul class="pagination">';
	if(1 != $pages){
		if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link(1)."'>İlk</a></li>";
		if($paged > 1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link($paged - 1)."' aria-label=\"Previous\"><span aria-hidden=\"true\">&laquo;</span</a></li>";
		for ($i=1; $i <= $pages; $i++) {
			if (1 != $pages && ( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
				echo ($paged == $i) ? "<li class=\"active\"><a href=\"#\">".$i."</a></li>" : "<li><a href='".get_pagenum_link($i)."'>".$i."</a></li>";
			}
		}
		if ($paged < $pages && $showitems < $pages) echo "<li><a href='".get_pagenum_link($paged + 1)."' aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
		if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<li><a href='".get_pagenum_link($pages)."'>Son</a></li>";
	}else {
		echo '<li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>';
	}
	echo ' </ul></nav>';
}

// CSS & JAVASCRİPT CODES HEADER S CLEANER
function CleanCode($type, $data) {
	$output = $data;
	$pattern = '@<'.$type.'(.*?)>(.*?)</'.$type.'>@is';
	if( preg_match($pattern,$data) ) {
		 $output = preg_replace($pattern, '$2', $output);
	}
	return $output;
}


////////// İLLER ////////////
function iller(){
	return array("Adana", "Adıyaman", "Afyon", "Ağrı", "Aksaray", "Amasya", "Ankara", "Antalya", "Ardahan", "Artvin", "Aydın", "Balıkesir", "Bartın", "Batman", "Bayburt", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa", "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Düzce", "Edirne", "Elazığ", "Erzincan", "Erzurum", "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Iğdır", "Isparta", "İçel", "İstanbul", "İzmir", "Kahramanmaraş", "Karabük", "Karaman", "Kars", "Kastamonu", "Kayseri", "Kırıkkale", "Kırklareli", "Kırşehir", "Kilis", "Kocaeli", "Konya", "Kütahya", "Malatya", "Manisa", "Mardin", "Muğla", "Muş", "Nevşehir", "Niğde", "Ordu", "Osmaniye", "Rize", "Sakarya", "Samsun", "Siirt", "Sinop", "Sivas", "Şanlıurfa", "Şırnak", "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Uşak", "Van", "Yalova", "Yozgat", "Zonguldak");
}


// HİKAYELER POST TYPE
function hikayeler_post_type() {
	$labels = array(
		'name'                  => _x( 'Hikayeler', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Hikayeler', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Hikayeler', 'text_domain' ),
		'name_admin_bar'        => __( 'Hikayeler', 'text_domain' ),
		'archives'              => __( 'Hikayeler Arşivi', 'text_domain' ),
		'parent_item_colon'     => __( 'Ebeveyn Hikaye:', 'text_domain' ),
		'all_items'             => __( 'Tüm Hikayeler', 'text_domain' ),
		'add_new_item'          => __( 'Yeni Hikaye Ekle', 'text_domain' ),
		'add_new'               => __( 'Hikaye Ekle', 'text_domain' ),
		'new_item'              => __( 'Yeni Hikaye', 'text_domain' ),
		'edit_item'             => __( 'Hikaye\'yi Düzenle', 'text_domain' ),
		'update_item'           => __( 'Hikaye\'yi Güncelle', 'text_domain' ),
		'view_item'             => __( 'Hikaye\'yi Görüntüle', 'text_domain' ),
		'search_items'          => __( 'Hikaye Ara', 'text_domain' ),
		'not_found'             => __( 'Bulunamadı', 'text_domain' ),
		'not_found_in_trash'    => __( 'Çöp Kutusunda Bulunamadı', 'text_domain' ),
		'featured_image'        => __( 'Ön Görsel', 'text_domain' ),
		'set_featured_image'    => __( 'Öne çıkarılmış görsel olarak belirle', 'text_domain' ),
		'remove_featured_image' => __( 'Ön görseli kaldır', 'text_domain' ),
		'use_featured_image'    => __( 'Ön görsel kullan', 'text_domain' ),
		'insert_into_item'      => __( 'Hikaye\'ye Ekle', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Hikaye\'ye Yüklendi', 'text_domain' ),
		'items_list'            => __( 'Hikaye Listesi', 'text_domain' ),
		'items_list_navigation' => __( 'Hikaye listesi navigasyonu', 'text_domain' ),
		'filter_items_list'     => __( 'Hikaye filtre listesi', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Hikayeler', 'text_domain' ),
		'description'           => __( 'Hikayeler ile ilgi kısım', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'comments', 'post-formats' ),
		'taxonomies'            => array(),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 7,
		'menu_icon'             => 'dashicons-id-alt',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
		'query_var' => true,
	);
	register_post_type( 'Hikayeler', $args );

}

add_action( 'init', 'hikayeler_post_type', 0 );


// URL REWRİTE
function wpse26388_rewrites_init(){
	global $wp_rewrite;
	add_rewrite_rule('^blog/?', 'index.php?pagename=blog', 'top' );
	add_rewrite_rule('^profile/([0-9]+)/?', 'index.php?pagename=profile&user_id=$matches[1]', 'top' );
    add_rewrite_rule('^profile/?', 'index.php?pagename=profile', 'top' );
}

function wpse26388_query_vars( $query_vars ){
    $query_vars[] = 'pagename';
    $query_vars[] = 'user_id';
    return $query_vars;
}

function portfolio_page_template( $template ) {	
	if ( get_query_var('pagename', "") == "profile" ) {
		if(get_query_var('user_id')) {
			$new_template = locate_template( array( 'profile.php' ) );
		} else {
			$new_template = locate_template( array( 'profile-edit.php' ) );
		}
		if ( '' != $new_template ) { return $new_template ; }
	} elseif ( get_query_var('pagename', "") == "blog" ) {
		$new_template = locate_template( array( 'blog.php' ) );
		if ( '' != $new_template ) { return $new_template ; }
	}

	return $template;
}

add_action( 'init', 'wpse26388_rewrites_init' );
add_filter( 'query_vars', 'wpse26388_query_vars' );
add_filter( 'template_include', 'portfolio_page_template', 99 );

?>