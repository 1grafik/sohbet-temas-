<?php if(!is_user_logged_in()) die('Bu sayfayı görme yetkiniz bulunmamaktadır!'); ?>

<?php get_header(); ?>

<?php 
	$userData = $current_user = wp_get_current_user();
	$userMeta = get_user_meta($userData->ID);
	$gender = ifReplace($userMeta['gender'][0], "");
?>

<div class="clearfix"></div>

<div class="container detay-genel" style="padding: 0px 10px; margin-top: 8px;">
	<div class="col-md-12 detay-baslik" style="padding: 0px; margin-top: 20px;">
		<span style="color: #515151"><a href="<?php echo home_url( '/' ); ?>" title="titlesi">Ana sayfa |</a></span>
		<a href="#" title="titlesi">Profilini Düzenle</a>
	</div>
	<div class="col-md-12" style="padding: 0px;margin-top: 5px;">

    <h1 style="margin: 0px; font-size: 18px;color: #7b7b7b; font-weight: 600; padding:15px 0;">PROFİLİ DÜZENLE</h1>
		
    <?php if(defined('REGISTRATION_ERROR')): foreach(unserialize(REGISTRATION_ERROR) as $error): ?>
    <div class="alert alert-danger alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button> <strong>Hata!</strong> <?php echo $error; ?> </div>
    <?php endforeach; elseif(defined('UPDATED_A_USER')): ?>
    <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button> <strong><span class="icon-ok"></span>Üyeliğiniz başarıyla güncellendi!</strong></div>
    <?php endif; ?>


		<?php if($userData): ?>
    <form class="form-group" action="<?php echo esc_url(home_url( '/profile/' )); ?>" id="userUpdateForm" method="POST">
			<div class="row input-group">
				<label>Kullanıcı Adınız</label>
				<input type="text" class="form-control" value="<?php echo $userData->user_login; ?>" disabled="disabled" readonly="readonly" />
			</div>

			<div class="row input-group">
				<label for="parola">Şifreniz (Boş bırakırsanız şifreniz değişmez)</label>
				<input type="password" id="parola" name="parola" class="form-control">
			</div>

			<div class="row input-group">
				<label for="nickadi">Nickiniz (Herkes görebilir. Kullanıcı adı değildir.)</label>
				<input type="text" id="nickadi" name="nickadi" class="form-control" value="<?php echo $userData->display_name; ?>" placeholder="<?php echo $userData->display_name; ?>" required="required">
			</div>
			
			<div class="row">
				<div class="col-sm-6 col-xs-12">
		      <div class="input-group">
						<label for="adi">Adınız</label>
			        <input type="text" id="adi" name="adi" class="form-control" value="<?php echo $userData->user_firstname; ?>" placeholder="<?php echo $userData->user_firstname; ?>" />
		      </div>
				</div>

				<div class="col-sm-6 col-xs-12">
		      <div class="input-group">
						<label for="soyadi">Soyadınız</label>
		        <input type="text" id="soyadi" name="soyadi" class="form-control" value="<?php echo $userData->user_lastname; ?>" placeholder="<?php echo $userData->user_lastname; ?>" />
		      </div>
				</div>
			</div>

			<div class="row input-group">
				<label for="eposta">E-Posta Adresi</label>
				<input type="email" id="eposta" name="eposta" class="form-control" placeholder="eposta adresiniz" value="<?php echo $userData->user_email; ?>" placeholder="<?php echo $userData->user_email; ?>" required="required">
			</div>

      <div class="input-group">
        <label for="user_email">Cinsiyetiniz</label>   
        <select id="gender" name="gender" class="form-control">
          <option value="" style="color: #cccccc;">cinsiyetiniz</option>
          <option value="Bay"<?php if($gender == "Bay") echo " selected"; ?>>Bay</option>
          <option value="Bayan"<?php if($gender == "Bayan") echo " selected"; ?>>Bayan</option>
        </select>
      </div>

      <div class="row input-group">
        <label for="user_email">Şehriniz</label> 
        <select id="city" name="city" class="form-control">
        <option value="" style="color: #cccccc;">şehriniz</option>
          <?php 
            $iller = iller();
            if(!empty($iller) && is_array($iller)) {
              foreach ($iller as $il){
                echo '<option value="' . $il . '"'.((ifReplace($userMeta['city'][0], "") == $il) ? ' selected' : null).'>' . $il . '</option>';
              }                    
            }
          ?>
        </select>
      </div>

      <div class="row input-group">
        <label for="birthday">Doğum Tarihiniz</label> 
        <input type="date" id="birthday" name="birthday" class="form-control" value="<?php echo ifReplace($userMeta['birthday'][0], ""); ?>" />
      </div>

      <div class="row input-group">
				<label for="uAvatar">Avatar (Url giriniz)</label>
        <input type="url" id="uAvatar" name="uAvatar" class="form-control" value="<?php echo ifReplace($userMeta['uAvatar'][0], ""); ?>" placeholder="<?php echo ifReplace($userMeta['uAvatar'][0], ""); ?>" />
      </div>

			<div class="row input-group">
				<label for="biyografi">Biyografi</label>
				<textarea name="biyografi" id="biyografi" class="form-control" cols="30" rows="10"><?php echo ifReplace($userMeta['description'][0], ""); ?></textarea>
			</div>

      <button type="submit" name="userUpdateForm" style="margin-top:15px;" class="btn btn-olustur btn-block">
        <span class="icon-hdd"></span>profili güncelle
      </button>
    </form>
		<?php else: ?>
			<div class="alert alert-danger" role="alert">
			  <strong>Üzgünüz!</strong> kullanıcıya erişilemedi. Lütfen tekrar deneyiniz!
			</div>
		<?php endif; ?>

	</div>
</div>

</div>

<div class="clearfix"></div>

<?php get_footer(); ?>