<?php get_header(); ?>

<?php if ( have_posts() ) : while(have_posts()) : the_post(); ?>

<div class="clearfix"></div>

<div class="container detay-genel" style="padding: 0px 10px; margin-top: 8px;">
	<div class="col-md-12 detay-baslik" style="padding: 0px; margin-top: 20px;">
		<span style="color: #515151"><a href="<?php echo home_url( '/' ); ?>" title="titlesi">Ana sayfa |</a></span>
		<a href="<?php the_permalink(); ?>" title="titlesi"><?php the_title(); ?></a>
	</div>
	<div class="col-md-12" style="padding: 0px; margin-top: 5px;">
		<?php the_content(); ?>
		<div class="col-md-12">
			<p class="pull-right" style="color: #6b6b6b;">Sayfa <?php the_author(); ?></a> Tarafından <span style="font-weight: 600;"><?php the_time('d.m.Y'); ?></span> Tarih, Saat <span style="font-weight: 600;"><?php the_time('g:i'); ?></span> ‘de Oluşturuldu.</p>
		</div>
		<?php if(ayar("reklam-on") == 1): ?>
		<div class="col-md-10 detay-reklam-alani col-md-offset-2">
			<?php echo ayar("opt-reklam"); ?>
		</div>
		<?php endif; ?>
	</div>
</div>
</div>

<div class="clearfix"></div>
			
<?php endwhile; endif; ?>

<?php wp_reset_postdata(); ?>



<?php get_footer(); ?>