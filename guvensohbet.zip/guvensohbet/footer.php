      <div class="clearfix"></div>
      <div class="container-fluid footer" style="padding: 0px;">
      <div class="container" style="padding: 0px;">
      <div class="col-md-5 col-xs-12" style="border-right: 1px solid #b8b8b8; margin-bottom: 20px;">
      <div class="col-md-6 col-xs-7" style="padding: 0px;">
      <?php 
        $footlogo = ayar("opt-footer-logo");
        echo '<img src="'.$footlogo["url"].'" width="'.$footlogo["width"].'" height="'.$logo["height"].'" alt="'.get_bloginfo('name').'" class="footer-logo">';
      ?>
      </div>
      <div class="col-md-6 col-xs-5 sosyaller sosyalmobi">
              <a href="<?php echo ayar("text-facebook"); ?>" title="Facebook"><i class="icon-facebook"></i></a>
              <a href="<?php echo ayar("text-twitter"); ?>" title="Twitter"><i class="icon-twitter-3"></i></a>
              <a href="<?php echo ayar("text-google"); ?>" title="Google+"><i class="icon-gplus"></i></a>
              <a href="<?php echo ayar("text-android"); ?>" title="Android"><i class="icon-android"></i></a>
      </div>
          <div class="clearfix"></div>
          <div class="col-md-6 col-sm-5" style="padding: 0px; margin-top: 10px;">
          <!-- Footer copyright -->
            <a href="https://www.1grafik.com" title="1Grafik - Web Tasarım ve Yazılım Hizmetleri"><img src="<?php echo get_template_directory_uri(); ?>/src/images/telif.png" alt="1grafik.com web tasarım ve yazılım" width="100" height="100" class="footer-asp" /></a>
          <!-- Emeğe saygı için lütfen silmeyiniz. bu linkleri silerseniz ücretsiz tema paylaşmak için sebebimiz kalmaz. -->
          </div>
        </div>

        <?php $footMenu = getMenuTitle(); ?>

        <div class="col-md-1"></div>
          <div class="col-md-6 footer-menu" style="padding: 0px;">
            <div class="col-md-4 col-sm-4 col-xs-6" style="margin-bottom: 10px;">
              <h3 style="font-size: 20px; color: #515151; padding: 0px; margin: 0px; margin-bottom: 10px;"><?php echo ifReplace($footMenu['footer-menu-1'], 'Footer Menü 1'); ?></h3>
              <?php wp_nav_menu(array( 'theme_location' => 'footer-menu-1' )); ?>
            </div>

            <div class="col-md-4 col-sm-4 col-xs-6" style="margin-bottom: 10px;">
              <h3 style="font-size: 20px; color: #515151; padding: 0px; margin: 0px; margin-bottom: 10px;"><?php echo ifReplace($footMenu['footer-menu-2'], 'Footer Menü 2'); ?></h3>
              <?php wp_nav_menu(array( 'theme_location' => 'footer-menu-2' )); ?>
            </div>

            <div class="col-md-4 col-sm-4 col-xs-6" style="margin-bottom: 10px;">
              <h3 style="font-size: 20px; color: #515151; padding: 0px; margin: 0px; margin-bottom: 10px;"><?php echo ifReplace($footMenu['footer-menu-3'], 'Footer Menü 3'); ?></h3>
              <?php wp_nav_menu(array( 'theme_location' => 'footer-menu-3' )); ?>
            </div>      
          </div>
      </div>
      
      </div>

    <script src="<?php echo get_template_directory_uri(); ?>/src/js/jquery.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/src/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/src/js/efekler.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/src/js/jquery.validate.min.js"></script>
    <script>
    $(document).ready(function(){
        $( ".asp2" ).effect( "slide", {}, 2200);
        $( ".ust-alan" ).effect( "slide", {}, 1000);
        $( ".radyom" ).effect( "slide", {}, 1500);
        $( ".kayitim" ).effect( "slide", {}, 3000);
    });
    </script>   

    <script>
        $(document).ready(function () {
            $('#myCarousel').carousel({
                interval: 1000
            });

            $('#custom_carousel').carousel({
                interval: 10000
            });
            
            $('.Carousel .item').each(function () {
                var next = $(this).next();
                if (!next.length) {
                    next = $(this).siblings(':first');
                }
                next.children(':first-child').clone().appendTo($(this));

                if (next.next().length > 0) {
                    next.next().children(':first-child').clone().appendTo($(this));
                }
                else {
                    $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
                }
            });

            $.extend( $.validator.messages, {
                required: "Bu alanın doldurulması zorunludur.",
                remote: "Lütfen bu alanı düzeltin.",
                email: "Lütfen geçerli bir e-posta adresi giriniz.",
                url: "Lütfen geçerli bir web adresi (URL) giriniz.",
                date: "Lütfen geçerli bir tarih giriniz.",
                dateISO: "Lütfen geçerli bir tarih giriniz(ISO formatında)",
                number: "Lütfen geçerli bir sayı giriniz.",
                digits: "Lütfen sadece sayısal karakterler giriniz.",
                creditcard: "Lütfen geçerli bir kredi kartı giriniz.",
                equalTo: "Lütfen aynı değeri tekrar giriniz.",
                extension: "Lütfen geçerli uzantıya sahip bir değer giriniz.",
                maxlength: $.validator.format( "Lütfen en fazla {0} karakter uzunluğunda bir değer giriniz." ),
                minlength: $.validator.format( "Lütfen en az {0} karakter uzunluğunda bir değer giriniz." ),
                rangelength: $.validator.format( "Lütfen en az {0} ve en fazla {1} uzunluğunda bir değer giriniz." ),
                range: $.validator.format( "Lütfen {0} ile {1} arasında bir değer giriniz." ),
                max: $.validator.format( "Lütfen {0} değerine eşit ya da daha küçük bir değer giriniz." ),
                min: $.validator.format( "Lütfen {0} değerine eşit ya da daha büyük bir değer giriniz." ),
                require_from_group: "Lütfen bu alanların en az {0} tanesini doldurunuz."
            } );

            $("form#userRegisterForm").validate({
                rules: { 
                    password: {
                        required: true,
                        minlength: 6
                    },
                    password_confirm: {
                        required: true,
                        equalTo: "#equalPass"
                    },
                    email: {
                        required: true,
                        email: true
                    }
                },
                messages: {
                    pswd: "Please enter password",
                    confirmpassword: "Please enter valid confirm password"
                }
            });
        });
    </script>
    <?php 
      $getMyScripts = ayar("opt-js");
      $cleanMyScripts = CleanCode("script", $getMyScripts);
      if($cleanMyScripts) echo '<script type="text/javascript">'.$cleanMyScripts.'</script>';
    ?>
    <?php wp_footer(); ?>
</body>
</html>