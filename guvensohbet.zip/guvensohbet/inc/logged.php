<?php $current_user = wp_get_current_user(); $currUserMeta = get_user_meta($current_user->ID); ?>

    <div class="container" style="padding: 0px; margin-top: -10px;">
      <div class="col-md-4 pull-right col-sm-12 hidden-xs profil-kayit" style="padding: 20px; background: #fff;z-index: 100">
        <h1 style="margin: 0px; font-size: 16px;color: #7b7b7b; font-weight: 600; padding:0px 10px; margin-bottom: 4px; ">
          <img src="<?php echo get_template_directory_uri(); ?>/src/images/profilico.png" alt="icon" width="44" height="39"/> SİTEMİZE HOŞGELDİNİZ 
        </h1>

        <div class="media">
          <div class="media-left">
            <?php echo userAvatar($current_user->ID, "media-object"); ?>
          </div>
          <div class="media-body">
            <h4 class="media-heading" style="font-size: 14px;color: #7b7b7b;font-weight: 600;margin-bottom: 2px;border-bottom: 1px dashed;padding-bottom: 6px;">ÖZET PROFİL</h4>
            <ul class="ozet-profil">
              <li>Nick:  <span class="c1"><?php echo $current_user->display_name; ?></span></li>
              <li>Adı:  <span class="c1"><?php echo ifReplace($current_user->user_firstname); ?></span></li>
              <li>Soyadı:  <span class="c1"><?php echo ifReplace($current_user->user_lastname); ?></span></li>
              <li>E-Posta:  <span class="c1"><?php echo $current_user->user_email; ?></span></li>
              <li>Üyelik Tarihi:  <span class="c1"><?php echo $current_user->user_registered; ?></span></li>
            </ul>
          </div>
        </div>

        <h4 style="font-size: 15px;color: #7b7b7b;margin: 15px 0;">Biyografi</h4>

        <div class="panel panel-default" style="min-height: 120px;">
          <div class="panel-body" style="max-height: 120px;overflow: auto;">
          <?php echo ifReplace($currUserMeta['description'][0], 'Profilinizi güncellerken bu alana hayat hikayenizi yazabilirsiniz.'); ?>
          </div>
        </div>

          <a href="<?php bloginfo('url'); ?>/profile/" style="margin-top:5px;" class="btn btn-olustur btn-block"><span class="icon-cog"></span>profilinizi güncelleyin</a>

      </div>