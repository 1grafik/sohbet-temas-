
    <div class="container" style="padding: 0px; margin-top: -10px;">
      <div class="col-md-4 pull-right col-sm-12 hidden-xs profil-kayit" style="padding: 20px; background: #fff;z-index: 100">
        <h1 style="margin: 0px; font-size: 16px;color: #7b7b7b; font-weight: 600; padding:0px 10px; margin-bottom: 4px; ">
          <img src="<?php echo get_template_directory_uri(); ?>/src/images/profilico.png" alt="icon" width="44" height="39"/>YENİ PROFİL KAYDI
        </h1>


        <?php if(defined('REGISTRATION_ERROR')): foreach(unserialize(REGISTRATION_ERROR) as $error): ?>
        <div class="alert alert-danger alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button> <strong>Hata!</strong> <?php echo $error; ?> </div>
        <?php endforeach; elseif(defined('REGISTERED_A_USER')): ?>
        <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button> <strong>Üyeliğiniz başarıyla kaydedildi!</strong> Email adresiniz <b><?php echo REGISTERED_A_USER_EMAIL; ?></b>, Kullanıcı adınız <b><?php echo REGISTERED_A_USER; ?></b>, Şifreniz <b><?php echo REGISTERED_A_USER_PASS; ?></b> olarak oluşturulmuştur. Sisteme giriş yapabilirsiniz.</div>
        <?php endif; ?>

        <?php if(get_option('users_can_register')): ?>
        <form class="form-group col-md-12" action="<?php echo esc_url(home_url( '/' )); ?>" id="userRegisterForm" method="post" style="padding:0px;">

          <div class="input-group input-small asp2" style="margin-top:5px;">
            <span class="input-group-addon danger" style="background: #fff !important; border: none;">
              <img src="<?php echo get_template_directory_uri(); ?>/src/images/kadico1.png" alt="icon" width="59" height="28" />
            </span>
            <input type="text" name="username" class="form-control" placeholder="kullanıcı adınız" required="required">
          </div>

          <div class="input-group asp2" style="margin-top:5px;">
            <span class="input-group-addon danger" style="background: #fff !important; border: none;">
              <img src="<?php echo get_template_directory_uri(); ?>/src/images/sifreico1.png" alt="icon" width="62" height="28" />
            </span>
            <input id="equalPass" type="password" name="password" class="form-control" placeholder="şifreniz" required="required">
          </div>

          <div class="input-group asp2" style="margin-top:5px;">
            <span class="input-group-addon danger" style="background: #fff !important; border: none;">
              <img src="<?php echo get_template_directory_uri(); ?>/src/images/sifreico1.png" alt="icon" width="62" height="28" />
            </span>
            <input type="password" name="password_confirm" class="form-control" placeholder="tekrar şifreniz" required="required">
          </div>

          <div class="input-group asp2" style="margin-top:5px;">
            <span class="input-group-addon danger" style="background: #fff !important; border: none;">
              <img src="<?php echo get_template_directory_uri(); ?>/src/images/epostaico.png" alt="icon" width="62" height="26" />
            </span>
            <input type="email" name="email" class="form-control" placeholder="eposta adresiniz" required="required">
          </div>

          <div class="input-group asp2" style="width: 100%; margin-top:5px;">
            <span class="input-group-addon danger" style="background: #fff !important; border: none;">
              <img src="<?php echo get_template_directory_uri(); ?>/src/images/cinsiyetico.png" alt="icon" width="62" height="28" />
            </span>   
            <select id="gender" name="gender" class="form-control">
              <option value="" style="color: #cccccc;">cinsiyetiniz</option>
              <option value="Bay">Bay</option>
              <option value="Bayan">Bayan</option>
            </select>
          </div>

          <div class="input-group asp2" style="width: 100%;margin-top:5px;">
            <span class="input-group-addon danger" style="background: #fff !important; border: none;">
              <img src="<?php echo get_template_directory_uri(); ?>/src/images/sehirico.png" alt="icon" width="62" height="29" />
            </span>
            <select id="city" name="city" class="form-control">
              <option value="" style="color: #cccccc;">şehriniz</option>
              <?php 
                $iller = iller();
                if(!empty($iller) && is_array($iller)) {
                  foreach ($iller as $il){
                    echo '<option value="' . $il . '">' . $il . '</option>';
                  }                    
                }
              ?>
            </select>
          </div>

          <div class="input-group asp2" style="width: 100%; margin-top:5px;">
            <span class="input-group-addon danger" style="background: #fff !important; border: none;">
              <img src="<?php echo get_template_directory_uri(); ?>/src/images/dogumico.png" alt="icon" width="62" height="28" />
            </span>
            <input type="date" id="dogumtarihi" name="birthday" />
          </div>

          <button type="submit" name="userRegisterForm" style="margin-top:5px;"  class="btn btn-olustur btn-block">
            <img src="<?php echo get_template_directory_uri(); ?>/src/images/olusturico.png" alt="icon" width="46" height="29" />profili oluştur
          </button>
        </form>
        <?php else: ?>
          <div class="alert alert-error"><button data-dismiss="alert" class="close">×</button><strong>Hata!</strong> Üye kayıtları durdurulmuştur. Lütfen daha sonra deneyiniz.</div>
        <?php endif; ?>
      </div>