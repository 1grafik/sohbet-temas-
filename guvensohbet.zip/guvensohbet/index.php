<?php get_header("home"); ?>

	<div class="clearfix"></div>

	<div class="container" style="padding: 0px; margin-top: -30px; margin-bottom: 10px; position: relative;">
		<div class="clearfix"></div>

		<!-- yeni profiller başladı -->
		<div class="col-md-3 col-xs-12 col-sm-12 profiller-baslik" style="padding: 0px; position: relative;">
			<span class="yeni-profiller" style="font-size: 17px;color: #8f8f8f"><img src="<?php echo get_template_directory_uri(); ?>/src/images/yeniprofillerico.png" alt="profil icon" width="36" height="20" style="vertical-align: text-bottom;" />Yeni Oluşturulan <span style="color: #f05252;">Profiller </span></span>
		</div>

		<div class="clearfix"></div>

		<div class="col-md-12" style="padding: 0px; margin-top: 20px;">
			<p style="color: #b0b0b0; font-weight: 500; font-size: 16px;"><i class="fa fa-spinner fa-spin" style="color: #f05252; margin-right: 3px;"></i>tamamen ücretsiz profil sayfamıza yeni kayıt olarak kendinizi gösterebilir, yeni arkadaşlıklar kurabilirsiniz.</p>
		</div>

		<div class="col-md-12" style="padding: 0px;">
			<div id="Carousel" class="carousel slide">                 
				<!-- Carousel items -->
				<div class="carousel-inner">
				<?php 
					$say = 0;
					$yeniUyelerItems = yeniUyeler(); 
					foreach ($yeniUyelerItems as $item) {
						echo '<div class="item'.(($say == 0) ? ' active' : null).'"><div class="row">';
						echo @implode(' ', $item);
						echo '</div></div>';
						$say++;
					}
				?>
				</div><!--.carousel-inner-->

				<a data-slide="prev" href="#Carousel" class="left carousel-control" style="background: none;"><img src="<?php echo get_template_directory_uri(); ?>/src/images/psol.png" alt="sol" width="42" height="67" /></a>
				<a data-slide="next" href="#Carousel" class="right carousel-control" style="background: none;"><img src="<?php echo get_template_directory_uri(); ?>/src/images/psag.png" alt="sol" width="38" height="67" /></a>
			</div><!--.Carousel-->
    </div>
    <!-- yeni profiller bitti -->

<?php 
	$say2 = 0;
	$hikayeler = new WP_Query(array('post_type' => 'Hikayeler', 'showposts' => 4));
	if ( $hikayeler->have_posts() ) : 
?>
<!-- hikayeler başladı -->
    <div class="clearfix"></div>
    <div class="col-md-12" style="padding: 0px;">
    	<div id="custom_carousel" class="carousel slide" data-ride="carousel" data-interval="2500">
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
        	<?php while($hikayeler->have_posts()) : $hikayeler->the_post(); ?>
            <div class="item<?php if($say2 == 0) echo ' active'; ?>">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3" style="margin-top: 10px;"><?php echo GetThumb('full', 'img-responsive blog-slider'); ?></div>
                        <div class="col-md-9">
                            <h3 class="text-center" style="font-size: 22px; color: #f05252; margin-bottom: 5px;"><?php the_title(); ?></h3>
                            <p style="color: #828282; font-size: 16px;"><?php echo mb_substr(get_the_content(), 0, 700, 'UTF-8') . '...'; ?></p>
                            <div class="col-md-6 col-sm-6" style="padding: 0px 15px 0px 0px">
                            <a href="<?php echo get_post_type_archive_link( 'hikayeler' ); ?>" title="titlesi" class="btn btn-block btn-tumhikaye">tüm tanışma hikayeleri</a>
                            </div>
                             <div class="col-md-6 col-sm-6" style="padding: 0px 0px 0px 15px">
                            <a href="<?php the_permalink(); ?>" title="titlesi" class="btn btn-block btn-tumhikaye">hikayenin devamı <i class="icon-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>            
            </div> <!-- End Item -->
        	<?php $say2++; endwhile; ?>
        </div><!-- End Carousel Inner -->
    	</div>

      <a data-slide="prev" href="#custom_carousel" class="left carousel-control" style="background: none;"><img src="<?php echo get_template_directory_uri(); ?>/src/images/sol.png" alt="sol" width="51" height="101" style="margin-top: 55px;" /></a>
      <a data-slide="next" href="#custom_carousel" class="right carousel-control" style="background: none;"><img src="<?php echo get_template_directory_uri(); ?>/src/images/ssag.png" alt="sag" width="51" height="101" class="ileri-geri" style="margin-top: 76px;" /></a>
    </div>
<!-- hikayeler bitti -->
<?php endif; ?>


<?php 
	$say2 = 0;
	$posts = new WP_Query(array('post_type' => 'post', 'showposts' => 4));
	if ( $posts->have_posts() ) : 
?>
	<!-- yazılar başladı -->
	<div class="clearfix"></div>
	<div class="col-md-10 col-md-offset-1"  style="border-top: 2px solid #dedede; margin-top:30px;"></div>
	<div class="col-md-12" style="padding: 0px; margin-top: 15px;">
		<h1 class="text-center" style="margin: 0px; font-size: 34px;color: #00213f; text-shadow: none; font-weight: 500; padding:0px 10px; margin-bottom: 4px; "><img src="<?php echo get_template_directory_uri(); ?>/src/images/blogico.png" alt="icon" width="38" height="35" style="vertical-align: text-bottom;"/>BLOG 	<span style="color: #959595; font-size: 20px;">YENİ YAZILAR</span></h1>
	</div>
	<div class="col-md-12" style="padding: 0px; margin-top: 20px;">
	<?php while($posts->have_posts()) : $posts->the_post(); ?>
		<div class="col-md-6 blog-haberleri">
			<div class="col-md-4 col-sm-4" style="padding: 0px 5px 0px 0px">
				<?php echo GetThumb('full', 'blog-img'); ?>
			</div>
	    <div class="col-md-8 col-sm-8">
    		<h2><?php the_title(); ?></h2>
        <div class="clearfix"></div>
        <p><?php echo mb_substr(get_the_excerpt(), 0, 160, 'UTF-8') . '...' ?></p>
        <div class="col-md-6 col-sm-6" style="padding: 0px;"><p><?php the_time('d.M.Y'); ?></p></div>
        <div class="col-md-6 col-sm-6 blog-devami" style="padding: 0px; margin-top: -3px;">
        	<a href="<?php the_permalink(); ?>" title="yazının devamı">yazının devamı <i class="icon-angle-double-right"></i></a>
        </div>
	    </div>
		</div>
	<?php endwhile; ?>
	<div class="clearfix"></div>
	<div class="col-md-12"><a href="<?php echo home_url( '/blog/' ); ?>" title="Tüm Blog Yazıları" class="btn btn-block btn-tumhikaye">tüm blog yazıları</a></div
	</div>
<!-- yazılar bitti -->
<?php endif; ?>

<?php get_footer(); ?>