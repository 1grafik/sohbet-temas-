<?php get_header(); ?>

<?php 
	$args = array(
		'post_type' => 'post', 
		'paged' => $paged,	
	); 
	$paged2 = (get_query_var('paged')) ? get_query_var('paged') : 0;
	$posts = new WP_Query($args);
	$pages2 = (int) $posts->max_num_pages;
?>

<div class="clearfix"></div>

<div class="container detay-genel" style="padding: 0px 10px; margin-top: 8px;">
	<div class="col-md-12 detay-baslik" style="padding: 0px; margin-top: 20px;">
		<span style="color: #515151"><a href="<?php echo home_url( '/' ); ?>" title="titlesi">Ana sayfa |</a></span>
		<a href="<?php echo home_url( '/blog/' ); ?>" title="titlesi">Blog Yazıları</a>
	</div>
	<div class="col-md-12" style="padding: 0px; margin-top: 5px;">


		<div id="postsList">
		<?php  if ( $posts->have_posts() ) : while($posts->have_posts()) : $posts->the_post(); ?>
			<div class="post-item clearfix">
			  <div class="col-md-2 col-sm-3 hidden-xs" style="padding: 0;">
			    <a href="<?php the_permalink(); ?>">
			      <?php echo GetThumb('thumbnail', 'img-responsive'); ?>
			    </a>
			  </div>
			  <div class="col-md-10 col-sm-9 col-xs-12">
			    <h4 class="c1"><?php the_title(); ?></h4>
			    <?php the_excerpt(); ?>
			    <a href="<?php the_permalink(); ?>" class="c1" title="Yazı Detayı" style="font-weight: bold;">Devamını Oku...</a>
			  </div>
			</div>
		<?php endwhile; endif; ?>
		</div>

		<div class="clearfix"><?php echo sayfalama($pages2, $paged2); ?></div>


	</div>
</div>
</div>

<div class="clearfix"></div>


<?php wp_reset_postdata(); ?>

<?php get_footer(); ?>
