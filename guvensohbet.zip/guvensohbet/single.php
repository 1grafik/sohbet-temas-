<?php get_header(); ?>

<?php if ( have_posts() ) : while(have_posts()) : the_post(); ?>

<div class="clearfix"></div>

<div class="container detay-genel" style="padding: 0px 10px; margin-top: 8px;">
	<div class="col-md-12 detay-baslik" style="padding: 0px; margin-top: 20px;">
		<span style="color: #515151"><a href="<?php echo home_url( '/' ); ?>" title="titlesi">Ana sayfa |</a></span>
		<a href="<?php the_permalink(); ?>" title="titlesi"><?php the_title(); ?></a>
	</div>
	<div class="col-md-12" style="padding: 0px; margin-top: 5px;">
		<?php echo GetThumb('full', 'detay-img'); ?>
		<?php the_content(); ?>
		<div class="clearfix" style="margin-top: 20px;">
			<p class="pull-left" style="color: #6b6b6b;">Yazı <?php the_author(); ?></a> Tarafından <span style="font-weight: 600;"><?php the_time('d.m.Y'); ?></span> Tarih, Saat <span style="font-weight: 600;"><?php the_time('g:i'); ?></span> ‘de Eklendi.</p>
			<div class="pull-right" style="margin: 5px 0 15px;">
				<span class="sst"><a href="https://twitter.com/share" class="twitter-share-button" data-count="horizontal" data-lang="tr" >Tweet</a><script type="text/javascript" src="https://platform.twitter.com/widgets.js" defer></script></span>
				<span class="ssg" style="margin-right: -32px;">
					<div class="g-plusone" data-size="medium" data-href="<?php the_permalink() ?>"></div>
					<script type="text/javascript">
					  window.___gcfg = {lang: 'tr'};

					  (function() {
						var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
						po.src = 'https://apis.google.com/js/platform.js';
						var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
					  })();
					</script>
				</span>
				<span class="ssf"><iframe defer src="https://www.facebook.com/plugins/like.php?href=<?php the_permalink() ?>&amp;send=false&amp;layout=button_count&amp;width=100&amp;show_faces=true&amp;action=like&amp;colorscheme=light&amp;font&amp;height=20" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:97px; height:20px;" allowTransparency="true"></iframe></span>
				<span class="ssf2" style="margin-left: -20px;"><a title="Facebook'tan Paylaş " href="http://www.facebook.com/share.php?u=<?php the_permalink() ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/src/images/fb.png" alt="Facebook" style="padding-right: 5px;padding-bottom: 2px;vertical-align: middle;"/><b>Paylaş</b></a></span>
			</div>
		</div>

		<?php if(ayar("reklam-on") == 1): ?>
		<div class="col-md-10 detay-reklam-alani col-md-offset-2">
			<?php echo ayar("opt-reklam"); ?>
		</div>
		<?php endif; ?>

		<div class="clearfix"></div>
		
		<div class="yorumlar">
			<a href="#respond" class="leavereplybutton">Yorum Yap</a>
			<?php comments_template(); ?> 
		</div>
	</div>
</div>
</div>

<div class="clearfix"></div>
			
<?php endwhile; endif; ?>

<?php wp_reset_postdata(); ?>



<?php get_footer(); ?>